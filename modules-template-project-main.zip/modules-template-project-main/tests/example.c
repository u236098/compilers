if(x > 3)
 printf("true");
else
 printf("false");
